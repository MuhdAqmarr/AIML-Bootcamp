username="sam1256"
print("welcome to python :",username)