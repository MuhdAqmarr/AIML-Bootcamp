# Assignment operators: =, +=, -=
# price=float(input("Enter Product Price"))
# discount=price*0.10
# disPrice=price-discount
# print(f"Price: {price} \nDiscount: {discount} \nDiscountedPrice:{disPrice}")
