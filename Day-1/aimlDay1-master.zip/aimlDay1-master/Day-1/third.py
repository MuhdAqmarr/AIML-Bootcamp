username="sameer" #string example
age=13  # integer example
salary=50000.50 #floating Number
isGraduate=False #Boolean
stayStatus=None #None

print("Given User Name is: ",username)
print("Age:",age)
print("Salary",salary)
print("Graduate: ",isGraduate)
print("StayStatus: ",stayStatus)